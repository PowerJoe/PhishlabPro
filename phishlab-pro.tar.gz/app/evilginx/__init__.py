from flask import Blueprint
evilginx_bp = Blueprint('evilginx', __name__)
from flask import render_template
from flask_login import login_required

@evilginx_bp.route('/dashboard')
@login_required
def dashboard():
    return "EvilGinx dashboard coming soon!"
