from flask import Blueprint
campaigns_bp = Blueprint('campaigns', __name__)
from flask import render_template
from flask_login import login_required

@campaigns_bp.route('/')
@login_required
def list_campaigns():
    return "Campaigns coming soon!"
